/**
 * The Server Can be configured and created here...
 * 
 * You can find the JSON Data file here in the Data module. Feel free to impliment a framework if needed.
 */

/*
-- This is the product data, you can view it in the file itself for more details 
{
    "_id": "019",
    "isActive": "false",
    "price": "23.00",
    "picture": "/img/products/N16501_430.png",
    "name": "Damage Reverse Thickening Conditioner",
    "about": "Dolor voluptate velit consequat duis. Aute ad officia fugiat esse anim exercitation voluptate excepteur pariatur sit culpa duis qui esse. Labore amet ad eu veniam nostrud minim labore aliquip est sint voluptate nostrud reprehenderit. Ipsum nostrud culpa consequat reprehenderit.",
    "tags": [
        "ojon",
        "conditioner"
    ]
}
*/
const { debug } = require('console');
const data = require('./data');
const qs = require('querystring');
const http = require('http');
const hostname = 'localhost';
const port = 3035;

/** 
 * Start the Node Server Here...
 * 
 * The http.createServer() method creates a new server that listens at the specified port.  
 * The requestListener function (function (req, res)) is executed each time the server gets a request. 
 * The Request object 'req' represents the request to the server.
 * The ServerResponse object 'res' represents the writable stream back to the client.
 */
http.createServer(function (req, res) {
    // .. Here you can create your data response in a JSON format

    //Set Response Header to handle the CORS
    res.setHeader('Access-Control-Allow-Origin', '*'); 
    res.setHeader('Access-Control-Allow-Methods', 'OPTIONS, GET');
    res.setHeader('Access-Control-Max-Age', 2592000); // 30 days

    //handle preflight request
    if (req.method == 'OPTIONS') {
        res.writeHead(200, {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'POST',
            'Access-Control-Allow-Headers': 'Content-Type'
        });
        res.end();
        return;
    }
    




    let body = [];
    if (req.method == 'POST') {

        req.on('data', function (chunk) {
            body.push(chunk);
        });
        req.on('end', function () {
                body = Buffer.concat(body).toString();
                const bodyAsJson = JSON.parse(body)
                //read the data file and search for the products  id where the id matches
                const products = searchProducts(bodyAsJson.searchKeyword);

                res.writeHead(200, { 'Content-Type': 'application/json' });
                const jsonObject = { searchResult : products};
                const jsonString = JSON.stringify(jsonObject);
                res.write(jsonString);
                res.end();
            
        });

    }




    //add get handling here
    if (req.method == 'GET') {
        res.write("Response goes in here..."); // Write out the default response
        res.end(); //end the response
    }
}).listen(port).enableCors = true;


/**
 * This function will search the products data for the search string, it will return all products if the search string is ALL_SKUS.
 * The search will look at the product name, about and tags.
 * @param {*} searchString
 * @returns 
 */
function searchProducts(searchString) {

    //if the search string is ALL_SKUS then return all products
    if(searchString !=null && searchString === 'ALL_SKUS'){
        return data;
    }

    var lowercaseSearch = searchString.toLowerCase(); // Convert search string to lowercase
    var filteredProducts = data.filter(function (product) {


      var lowercaseName = product.name.toLowerCase();
      var lowercaseAbout = product.about.toLowerCase();
      var lowercaseTags = new Set(product.tags.map(function (tag) {
        return tag.toLowerCase();
      }));
      
      if (
        lowercaseName.includes(lowercaseSearch) ||
        lowercaseAbout.includes(lowercaseSearch)
      ) {
        return true;
      }
      
      // Check if any tag matches the search string
      for (var tag of lowercaseTags) {
        if (tag.includes(lowercaseSearch)) {
          return true;
        }
      }
      
      return false;
    });
  
    return filteredProducts;
  }
  



console.log(`[Server running on ${hostname}:${port}]`);
